/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package q2aa2_tau_badong.reccion.vitan;

/**
 *
 * @author Meredith Vitan
 */
public class DisposableTool extends Tool{
    protected String name, message;
    protected int noiseUnit, lightUnit;
    
    public void DisposableTool(String name, String message, int noiseUnit, int lightUnit){
        super(name, message, noiseUnit, lightUnit);
    }
}
