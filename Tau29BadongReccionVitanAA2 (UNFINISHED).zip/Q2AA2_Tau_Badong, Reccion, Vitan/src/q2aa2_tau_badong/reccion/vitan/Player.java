/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package q2aa2_tau_badong.reccion.vitan;

/**
 *
 * @author Meredith Vitan
 */
public class Player {
    private String name;
    private int noiseMeter, lightMeter;
    private ArrayList<Tool> inventory;
    
    public void Player(String name){
        this.name = name;
        inventory = null;
        noiseMeter = 0;
        lightMeter = 0;
    }
    
    public void pickUp(Tool tool){
        
    }
}
