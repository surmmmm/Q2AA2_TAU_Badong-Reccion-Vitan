/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package q2aa2_tau_badong.reccion.vitan;

/**
 *
 * @author Meredith Vitan
 */
public class Tool {
    protected String name, message;
    protected int noiseUnit, lightUnit;
    protected Obstacle unlocksWhat;
    
    public void Tool(String name, String message, int noiseUnit, int lightUnit, Obstacle unlocksWhat){
        this.name = name;
        this.message = message;
        this.noiseUnit = noiseUnit;
        this.lightUnit = lightUnit;
        this.unlocksWhat = unlocksWhat;
    }
    public void Tool(String name, String message, int noiseUnit, int lightUnit){
        this.name = name;
        this.message = message;
        this.noiseUnit = noiseUnit;
        this.lightUnit = lightUnit;
    }
    
    public Tool unlock(Obstacle obstacle){
        obstacle.makeInteractive();
    }
}
